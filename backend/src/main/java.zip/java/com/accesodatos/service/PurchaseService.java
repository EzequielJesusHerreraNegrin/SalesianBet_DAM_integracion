package com.accesodatos.service;

public interface PurchaseService {

	Boolean buyUserBasketProducts(Long id);
	
}
