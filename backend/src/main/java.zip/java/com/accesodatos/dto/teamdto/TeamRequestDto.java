package com.accesodatos.dto.teamdto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TeamRequestDto {

	private String teamName;
	private String sport;	
}
