package com.accesodatos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.accesodatos.dto.api.ApiResponseDto;
import com.accesodatos.dto.cartitem.CartItemRequestDto;
import com.accesodatos.dto.cartitem.CartItemResponseDto;
import com.accesodatos.service.CartItemServiceImpl;

@RestController
@RequestMapping("api/v1")
public class CartItemController {

	private static final String CARTITEM_RESOURCE = "/cartItems";
	private static final String CARTITEM_USER_ID = CARTITEM_RESOURCE + "/user/{id}";
	
	@Autowired CartItemServiceImpl cartItemServiceImpl;
	
	@GetMapping(value = CARTITEM_RESOURCE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponseDto<List<CartItemResponseDto>>> getAllCartItems() {
		List<CartItemResponseDto> items = cartItemServiceImpl.getAllCartItems();
		
		ApiResponseDto<List<CartItemResponseDto>> response = new ApiResponseDto<List<CartItemResponseDto>>("All items were fetched successfuly", HttpStatus.OK.value(), items);
		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@PostMapping(value = CARTITEM_RESOURCE+ "/{userId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponseDto<Boolean>> addProductToCart(
			@RequestBody CartItemRequestDto dto,@PathVariable Long userId) {
		
		Boolean items = cartItemServiceImpl.addproductToCart(userId, dto);
		
		ApiResponseDto<Boolean> response = new ApiResponseDto<Boolean>("All items were fetched successfuly", HttpStatus.OK.value(), items);
		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@PostMapping(value = CARTITEM_USER_ID, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponseDto<Boolean>> buyCartItems(@PathVariable Long id) {
		
		Boolean items = cartItemServiceImpl.buyCartItems(id);
		
		ApiResponseDto<Boolean> response = new ApiResponseDto<Boolean>("Purchase has been processed successfuly.", HttpStatus.OK.value(), items);
		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
