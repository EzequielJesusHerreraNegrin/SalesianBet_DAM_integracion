package com.accesodatos.entity.enums;

public enum ProductState {

	DESCATALOGADO,
	PUBLICO
}
