package com.accesodatos.dto.teamdto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TeamResponseDto {

	private Long teamId;
	private String teamName;
}
