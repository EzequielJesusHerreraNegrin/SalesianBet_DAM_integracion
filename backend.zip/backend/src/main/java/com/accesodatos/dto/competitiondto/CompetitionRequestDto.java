package com.accesodatos.dto.competitiondto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CompetitionRequestDto {

	private String name;
	private String country;
}
